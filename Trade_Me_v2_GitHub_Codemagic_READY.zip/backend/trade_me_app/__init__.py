"""Trade Me app layer: read-only UI service around the hardened engine.
Never imports the execution package. Contains no order calls, loops, timers or threads."""

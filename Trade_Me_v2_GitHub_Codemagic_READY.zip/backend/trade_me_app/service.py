"""App service: turns engine output into UI-ready data and enforces safe manual approval.

Every method is a single user/UI-triggered call. No loop, timer, thread or execution import.
"""
from dataclasses import asdict, is_dataclass
from datetime import datetime, timezone
from enum import Enum
from typing import Optional
import os
from pathlib import Path


from trade_me import (AccountState, ApprovalError, ApprovalQueue, EngineConfig, MarketScanner,
                      ScanInput, SetupStatus, Signal, TradeMeEngine, format_setup)
from trade_me.risk import assess_risk
from trade_me.strategy import config_from_env
from trade_me.journal import DecisionJournal
from trade_me.audit import AuditTrail
from trade_me.risk_policy import RiskPolicy, additional_blocks
from trade_me.safety import SafetyState
from trade_me.health import health_snapshot
from trade_me.decision import stage as decision_stage

CONNECTED, CONNECTING, OFFLINE, ERROR = "CONNECTED", "CONNECTING", "OFFLINE", "ERROR"
MAX_SETUP_AGE_SECONDS = 15 * 60          # UI-side staleness limit (checked on approve only)
MAX_DATA_AGE_SECONDS = 5 * 60            # market data older than this is shown as STALE
MSG_DISCONNECTED = "MT5 disconnected"
MAX_PRICE_DRIFT_STOP_FRACTION = 0.25     # price may move at most 25% of the stop distance


def _plain(v):
    if isinstance(v, Enum):
        return v.value
    if isinstance(v, datetime):
        return v.isoformat()
    if is_dataclass(v):
        return {k: _plain(x) for k, x in asdict(v).items()}
    if isinstance(v, dict):
        return {k: _plain(x) for k, x in v.items()}
    if isinstance(v, (list, tuple)):
        return [_plain(x) for x in v]
    if hasattr(v, "isoformat"):
        return v.isoformat()
    return v


def _last_candle_time(candles):
    try:
        t = candles["time"].iloc[-1]
        return t.isoformat() if hasattr(t, "isoformat") else str(t)
    except Exception:
        return None


def market_status(result) -> str:
    if result.error:
        return "ERROR"
    if result.setup is not None:
        return "BLOCKED" if result.setup.status == SetupStatus.BLOCKED else f"{result.setup.signal.value} SETUP"
    return "WAIT"


def split_confirmations(setup) -> dict:
    """Same-direction evidence vs opposite evidence, using the engine's own names."""
    want = "BULLISH" if setup.signal == Signal.BUY else "BEARISH"
    same_dir = {"BULLISH_ENGULFING", "BULLISH_REJECTION", "DOUBLE_BOTTOM"} if want == "BULLISH" \
        else {"BEARISH_ENGULFING", "BEARISH_REJECTION", "DOUBLE_TOP"}
    supporting = [p for p in setup.patterns if p in same_dir] + \
                 [c for c in setup.confirmations if c.startswith(want)]
    other = [p for p in setup.patterns if p not in same_dir] + \
            [c for c in setup.confirmations if not c.startswith(want)]
    return {"supporting": supporting, "opposite": other}


class TradeMeService:
    def __init__(self, feed=None, symbols=(), timeframe="M15", config: Optional[EngineConfig] = None,
                 clock=None):
        self.feed, self.symbols, self.timeframe = feed, list(symbols), timeframe
        self.config = config_from_env(config or EngineConfig())
        self.scanner = MarketScanner(self.config)
        self.queue = ApprovalQueue()
        self.clock = clock or (lambda: datetime.now(timezone.utc))
        self.connection = {"state": OFFLINE if feed is None else CONNECTING,
                           "message": MSG_DISCONNECTED if feed is None else "Connecting to MT5"}
        self.results: dict = {}
        self.first_seen: dict = {}
        self.candle_time: dict = {}      # symbol -> time of the newest closed candle actually received
        self.last_scan_at = None         # when MT5 data was last fetched successfully (service clock)
        self.stale = False
        self.push_subscriptions = {}
        self.push_notified_setups = set()
        self.last_notified_connection = self.connection["state"]
        self.multi_timeframes = ("M5", "M15", "H1", "H4")
        data_dir = Path(os.environ.get("TRADE_ME_DATA_DIR", "data"))
        self.journal = DecisionJournal(data_dir / "decision_journal.jsonl")
        self.audit = AuditTrail(self.journal)
        self.safety = SafetyState(data_dir / "safety_state.json")
        self.kill_switch = self.safety.enabled
        self.risk_policy = RiskPolicy(
            max_daily_approvals=self.config.max_daily_approvals,
            max_total_position_volume=self.config.max_total_position_volume,
            max_symbol_positions=self.config.max_symbol_positions,
            max_stop_atr_multiple=self.config.max_stop_atr_multiple,
            max_currency_exposure_units=self.config.max_currency_exposure_units,
        )

    # ---------------------------------------------------------------- connection
    def connect(self):
        previous = self.connection["state"]
        if self.feed is None:
            self.connection = {"state": OFFLINE, "message": MSG_DISCONNECTED}
            return self.connection
        self.connection = {"state": CONNECTING, "message": "Connecting to MT5"}
        try:
            self.feed.connect()
            self.feed.account()
            self.connection = {"state": CONNECTED, "message": "Analysis ready"}
        except Exception as exc:
            self.connection = {"state": ERROR, "message": MSG_DISCONNECTED, "detail": str(exc)}
        self._notify_connection_change(previous)
        self.audit.record("connection", state=self.connection["state"], message=self.connection["message"])
        return self.connection

    def probe(self) -> dict:
        """Cheap read-only liveness check used before answering a read. Never reconnects by itself
        (reconnecting is a user action) and never invents a state: if MT5 stops answering, the state
        becomes ERROR and old data is flagged stale."""
        if self.connection["state"] == CONNECTED:
            try:
                self.feed.account()
            except Exception as exc:
                self._lost(exc)
        return self.connection

    # ---------------------------------------------------------------- freshness
    def age_seconds(self):
        return None if self.last_scan_at is None else max(0.0, (self.clock() - self.last_scan_at).total_seconds())

    def is_stale(self) -> bool:
        age = self.age_seconds()
        return bool(self.stale) or (age is not None and age > MAX_DATA_AGE_SECONDS)

    def freshness(self) -> dict:
        age = self.age_seconds()
        state = "NONE" if age is None else ("STALE" if self.is_stale() else "CURRENT")
        return {"state": state, "data_as_of": self.last_scan_at.isoformat() if self.last_scan_at else None,
                "age_seconds": age, "max_age_seconds": MAX_DATA_AGE_SECONDS,
                "server_time": self.clock().isoformat()}

    # ---------------------------------------------------------------- account
    def account_state(self) -> Optional[AccountState]:
        if self.connection["state"] != CONNECTED:
            return None
        try:
            from trade_me.monitoring import AccountMonitor
            now = self.clock()
            day_start = now.replace(hour=0, minute=0, second=0, microsecond=0)
            return AccountMonitor(self.feed).snapshot(day_start, now).to_account_state()
        except Exception as exc:
            self._lost(exc)
            return None

    def monitor(self) -> dict:
        """Read-only trades/account view. Never fake data: unavailable => explicit flag."""
        if self.connection["state"] != CONNECTED:
            return {"available": False, "message": self.connection["message"]}
        try:
            from trade_me.monitoring import AccountMonitor
            now = self.clock()
            snap = AccountMonitor(self.feed).snapshot(now.replace(hour=0, minute=0, second=0, microsecond=0), now)
            return {"available": True, **_plain(snap)}
        except Exception as exc:
            self._lost(exc)
            return {"available": False, "message": self.connection["message"]}

    def _lost(self, exc):
        previous = self.connection["state"]
        self.connection = {"state": ERROR, "message": MSG_DISCONNECTED, "detail": str(exc)}
        self.stale = True
        self._notify_connection_change(previous)
        self.audit.record("connection", state=self.connection["state"], message=MSG_DISCONNECTED)

    # ---------------------------------------------------------------- scanning (one call = one scan)
    def scan(self) -> list:
        account = self.account_state()
        if account is None:
            self.stale = True            # keep old results, but flagged as stale
            return list(self.results.values())
        inputs, results = [], {}
        for s in self.symbols:           # per-symbol read isolation
            try:
                candles = self.feed.rates(s, self.feed.timeframe(self.timeframe), 300)
                inputs.append(ScanInput(s, candles, self.feed.symbol_spec(s), self.feed.spread_points(s)))
                self.candle_time[s] = _last_candle_time(candles)
            except Exception as exc:
                from trade_me import ScanResult
                results[s] = ScanResult(s, error="Market data unavailable")
        for r in self.scanner.scan(inputs, account, queue=self.queue):
            results[r.symbol] = r
            if r.setup is not None:
                is_new = r.setup.setup_id not in self.first_seen
                self.first_seen.setdefault(r.setup.setup_id, self.clock())
                if is_new:
                    self.audit.record("setup_detected", setup_id=r.setup.setup_id, symbol=r.symbol,
                                      signal=r.setup.signal.value, stage=decision_stage(r.setup))
                if is_new and r.setup.setup_id not in self.push_notified_setups:
                    self.push_notified_setups.add(r.setup.setup_id)
                    self.push_event("setup", f"{r.setup.signal.value} setup: {r.symbol}",
                                    f"A new {r.setup.signal.value} setup is ready for review.", r.setup.setup_id)
        self.results = {s: results[s] for s in self.symbols if s in results}
        if inputs:                       # at least one market really came from MT5 just now
            self.last_scan_at, self.stale = self.clock(), False
        else:                            # nothing fresh was obtained: never present it as current
            self.stale = True
        return list(self.results.values())

    # ---------------------------------------------------------------- UI payloads
    def markets(self) -> dict:
        return {"connection": self.connection, "stale": self.is_stale(), "freshness": self.freshness(), "markets": [
            {"symbol": r.symbol, "status": market_status(r), "last_candle_time": self.candle_time.get(r.symbol),
             "direction": r.analysis.direction.value if r.analysis else None,
             "phase": r.analysis.phase.value if r.analysis else None,
             "message": r.error or (r.analysis.reason if r.analysis else "")}
            for r in self.results.values()]}

    def setup_payload(self, setup) -> dict:
        d = _plain(setup)
        d["evidence"] = split_confirmations(setup)
        d["why"] = setup.reason
        d["details_text"] = format_setup(setup)
        d["is_stale_data"] = self.is_stale()
        d["decision_stage"] = decision_stage(setup)
        d["audit"] = {"setup_id": setup.setup_id, "recorded": True}
        return d

    def setups(self) -> dict:
        return {"connection": self.connection, "stale": self.is_stale(), "freshness": self.freshness(),
                "setups": [self.setup_payload(s) for s in self.queue.all()]}

    # ---------------------------------------------------------------- approval safety
    def approve(self, setup_id: str) -> dict:
        """Approve only if the CURRENT situation still supports the setup. Otherwise the old
        setup is expired (never approved) and re-analysis is required."""
        try:
            old = self.queue.get(setup_id)
        except ApprovalError as exc:
            return {"ok": False, "message": str(exc)}
        if old.status != SetupStatus.WAITING:
            return {"ok": False, "message": f"Setup is {old.status.value}", "status": old.status.value}
        if self.kill_switch:
            self.audit.record("approval_blocked", setup_id=setup_id, reason="Kill switch active")
            return {"ok": False, "message": "Kill switch is active", "status": "BLOCKED"}
        problems = self._recheck(old)
        if problems:
            self.queue.expire(setup_id, "Setup changed: " + "; ".join(problems))
            return {"ok": False, "message": "Setup changed", "detail": "Re-analysis required",
                    "problems": problems, "status": SetupStatus.EXPIRED.value}
        s = self.queue.approve(setup_id, "Approved by user after re-check")
        self.audit.record("approval", setup_id=setup_id, symbol=s.symbol, signal=s.signal.value, status=s.status.value)
        return {"ok": True, "message": "Setup approved (nothing was sent to your broker)",
                "status": s.status.value}

    def reject(self, setup_id: str) -> dict:
        try:
            s = self.queue.reject(setup_id, "Rejected by user")
        except ApprovalError as exc:
            return {"ok": False, "message": str(exc)}
        self.audit.record("rejection", setup_id=setup_id, symbol=s.symbol, signal=s.signal.value, status=s.status.value)
        return {"ok": True, "message": "Setup rejected", "status": s.status.value}

    def _recheck(self, old) -> list:
        p = []
        if self.connection["state"] != CONNECTED:
            return [MSG_DISCONNECTED]
        cfg = self.config
        now = self.clock()
        seen = self.first_seen.get(old.setup_id)
        if seen is not None and (now - seen).total_seconds() > MAX_SETUP_AGE_SECONDS:
            p.append("Setup is expired")
        if old.stop_loss is None or old.take_profit is None or old.position_size <= 0:
            return p + ["Stop loss, take profit or size missing"]
        try:
            account = self.account_state()
            if account is None:
                return p + ["Account data unavailable"]
            candles = self.feed.rates(old.symbol, self.feed.timeframe(self.timeframe), 300)
            spec, spread = self.feed.symbol_spec(old.symbol), self.feed.spread_points(old.symbol)
            tick = self.feed.tick(old.symbol)
        except Exception:
            return p + ["Market data unavailable"]
        eng = TradeMeEngine(cfg)
        fresh = eng.propose_setup(old.symbol, candles, account, spec, spread)
        if fresh is None or fresh.signal != old.signal:
            return p + ["Setup no longer exists or direction changed"]
        if fresh.status == SetupStatus.BLOCKED:
            p += fresh.blocked_reasons
        buy = old.signal == Signal.BUY
        price = tick["ask"] if buy else tick["bid"]
        if abs(price - old.entry) > MAX_PRICE_DRIFT_STOP_FRACTION * old.stop_distance:
            p.append("Price has moved too far from the proposed entry")
        if (buy and not old.stop_loss < price < old.take_profit) or \
           (not buy and not old.take_profit < price < old.stop_loss):
            p.append("Stop loss or take profit is no longer valid at the current price")
        ra = assess_risk(account.equity, cfg.risk_percent, old.stop_distance, spec.value_per_price_unit,
                         spread, cfg.max_spread_points, account.daily_loss_percent,
                         cfg.max_daily_loss_percent, account.open_positions, cfg.max_open_positions,
                         spec.min_volume, spec.max_volume, spec.volume_step)
        p += ra.blocked_reasons
        try:
            positions = self.feed.positions()
            daily_approvals = self.journal.count_today("approval")
            p += additional_blocks(old, positions, self.risk_policy, daily_approvals, fresh.atr)
        except Exception:
            p.append("Portfolio risk data unavailable")
        if ra.position_size != old.position_size:
            p.append("Position size changed")
        if abs(fresh.entry - old.entry) > 1e-12 and fresh.setup_id != old.setup_id:
            p.append("A newer candle produced a different setup")
        return list(dict.fromkeys(p))

    # ---------------------------------------------------------------- safety / journal / health / replay
    def set_kill_switch(self, enabled: bool) -> dict:
        self.kill_switch = self.safety.set(bool(enabled))
        self.audit.record("kill_switch", enabled=self.kill_switch)
        return {"ok": True, "kill_switch": self.kill_switch,
                "message": "Kill switch active: approvals blocked" if self.kill_switch else "Kill switch cleared: approvals may be reviewed again"}

    def health(self) -> dict:
        return health_snapshot(self)

    def journal_payload(self, limit=100) -> dict:
        return {"records": self.journal.recent(max(1, min(int(limit), 500)))}

    def ai_context(self) -> dict:
        markets = self.markets()
        setups = self.setups()
        return {
            "purpose": "Trade Me explanatory analysis context; not an order instruction",
            "generated_at": self.clock().isoformat(),
            "connection": self.connection,
            "freshness": self.freshness(),
            "markets": markets.get("markets", []),
            "active_setups": setups.get("setups", []),
            "risk_policy": _plain(self.config),
            "safety": {"kill_switch": self.kill_switch, "execution_enabled": False},
        }

    def replay(self, payload: dict) -> dict:
        from trade_me.replay import replay
        import pandas as pd
        candles = payload.get("candles") if isinstance(payload, dict) else None
        if not isinstance(candles, list) or len(candles) < 80:
            return {"ok": False, "message": "Replay requires at least 80 OHLC candles"}
        try:
            df = pd.DataFrame(candles)
            required = {"open", "high", "low", "close"}
            if not required.issubset(df.columns):
                return {"ok": False, "message": "Candles must contain open, high, low and close"}
            symbol = str(payload.get("symbol") or (self.symbols[0] if self.symbols else "EURUSD"))
            return {"ok": True, **replay(df, symbol=symbol, config=self.config, max_steps=min(int(payload.get("max_steps", 250)), 500))}
        except Exception as exc:
            return {"ok": False, "message": f"Replay failed ({type(exc).__name__})"}

    # ---------------------------------------------------------------- notifications / advanced analysis
    def notification_settings(self) -> dict:
        return {
            "push_configured": bool(os.environ.get("TRADE_ME_VAPID_PUBLIC_KEY")),
            "subscription_count": len(self.push_subscriptions),
            "events": ["setup", "connection"],
        }

    def register_push(self, subscription: dict) -> dict:
        endpoint = subscription.get("endpoint") if isinstance(subscription, dict) else None
        keys = subscription.get("keys") if isinstance(subscription, dict) else None
        if not endpoint or not isinstance(keys, dict) or not keys.get("p256dh") or not keys.get("auth"):
            return {"ok": False, "message": "Invalid push subscription"}
        self.push_subscriptions[endpoint] = subscription
        return {"ok": True, "message": "Push notifications enabled"}

    def unregister_push(self, endpoint: str) -> dict:
        self.push_subscriptions.pop(endpoint, None)
        return {"ok": True, "message": "Push notifications disabled"}

    def push_event(self, event: str, title: str, body: str, tag: str) -> int:
        """Best-effort Web Push delivery. No trading action is performed here."""
        if not self.push_subscriptions or not os.environ.get("TRADE_ME_VAPID_PRIVATE_KEY"):
            return 0
        try:
            from pywebpush import webpush
            private_key = os.environ["TRADE_ME_VAPID_PRIVATE_KEY"]
            subject = os.environ.get("TRADE_ME_VAPID_SUBJECT", "mailto:trademe@localhost")
            payload = {"event": event, "title": title, "body": body, "tag": tag}
            sent = 0
            for endpoint, sub in list(self.push_subscriptions.items()):
                try:
                    webpush(subscription_info=sub, data=__import__('json').dumps(payload),
                            vapid_private_key=private_key, vapid_claims={"sub": subject})
                    sent += 1
                except Exception as exc:
                    status = getattr(getattr(exc, "response", None), "status_code", None)
                    if status in (404, 410):
                        self.push_subscriptions.pop(endpoint, None)
            return sent
        except ImportError:
            return 0

    def _notify_connection_change(self, previous_state):
        current = self.connection["state"]
        if current == previous_state:
            return
        self.last_notified_connection = current
        if current == CONNECTED:
            self.push_event("connection", "Trade Me connected", "MT5 connection is ready.", "connection")
        elif current in (OFFLINE, ERROR):
            self.push_event("connection", "Trade Me connection", "MT5 is disconnected. No live analysis is being shown.", "connection")

    def multi_analysis(self, timeframes=None) -> dict:
        """Read-only analysis across several timeframes. Does not submit setups to the approval queue."""
        if self.connection["state"] != CONNECTED:
            return {"available": False, "connection": self.connection, "timeframes": []}
        account = self.account_state()
        if account is None:
            return {"available": False, "connection": self.connection, "timeframes": []}
        frames = list(timeframes or self.multi_timeframes)
        out = []
        for tf in frames:
            row = {"timeframe": tf, "markets": []}
            try:
                mt_tf = self.feed.timeframe(tf)
            except Exception:
                row["error"] = "Timeframe unavailable"
                out.append(row); continue
            for symbol in self.symbols:
                try:
                    candles = self.feed.rates(symbol, mt_tf, 300)
                    spec = self.feed.symbol_spec(symbol)
                    spread = self.feed.spread_points(symbol)
                    result = MarketScanner(self.config).scan([ScanInput(symbol, candles, spec, spread)], account)[0]
                    row["markets"].append({
                        "symbol": symbol,
                        "direction": result.analysis.direction.value if result.analysis else None,
                        "phase": result.analysis.phase.value if result.analysis else None,
                        "signal": result.analysis.signal.value if result.analysis else None,
                        "reason": result.analysis.reason if result.analysis else result.error,
                        "error": result.error,
                    })
                except Exception:
                    row["markets"].append({"symbol": symbol, "error": "Analysis unavailable"})
            out.append(row)
        return {"available": True, "connection": self.connection, "timeframes": out}

    def history(self, days=7) -> dict:
        if self.connection["state"] != CONNECTED:
            return {"available": False, "message": self.connection["message"], "days": days, "history": []}
        try:
            from datetime import timedelta
            end = self.clock(); start = end - timedelta(days=max(1, min(int(days), 90)))
            from trade_me.monitoring import AccountMonitor
            snap = AccountMonitor(self.feed).snapshot(start, end)
            return {"available": True, "days": int(days), "history": _plain(snap.history),
                    "summary": {"deals": len(snap.history), "profit": sum(x.profit for x in snap.history)}}
        except Exception as exc:
            self._lost(exc)
            return {"available": False, "message": self.connection["message"], "days": days, "history": []}

    # ---------------------------------------------------------------- settings (real engine values)
    def settings(self) -> dict:
        return {"mode": "Manual Trading Mode",
                "statement": "Trade Me analyses markets and presents setups. You decide whether to act.",
                "risk": _plain(self.config), "markets": self.symbols, "timeframe": self.timeframe,
                "connection": self.connection,
                "safety": {"kill_switch": self.kill_switch, "execution_enabled": False},
                "strategy_source": "EngineConfig defaults + TRADE_ME_* environment overrides"}

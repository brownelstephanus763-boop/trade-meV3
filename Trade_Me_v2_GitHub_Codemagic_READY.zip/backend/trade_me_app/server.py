"""Thin request-driven JSON bridge for the mobile UI. Read-only except for the explicit
user actions approve/reject (which only mark a setup; nothing is sent to a broker).
No background thread, timer or loop of our own: work happens only inside a request.

Access control (see README): bound to localhost the bridge needs no token. Bound to any other
address a token is REQUIRED (create_app refuses to start without one) and every /api/ request must
carry it in the X-Trade-Me-Token header (never in a URL, never logged). The token is compared in
constant time. Every response is Cache-Control: no-store."""
import hmac
from pathlib import Path

from flask import Flask, jsonify, request, send_from_directory
import os
from werkzeug.exceptions import HTTPException

from .service import TradeMeService

STATIC = Path(__file__).parent / "static"
LOOPBACK_HOSTS = {"127.0.0.1", "localhost", "::1"}
TOKEN_HEADER = "X-Trade-Me-Token"


def create_app(service: TradeMeService, token=None, host="127.0.0.1") -> Flask:
    token = token or None
    if host not in LOOPBACK_HOSTS and not token:
        raise ValueError("An access token is required when the bridge is reachable beyond localhost")
    app = Flask(__name__, static_folder=None)

    @app.before_request
    def guard():
        if not request.path.startswith("/api/"):
            return None                              # the UI shell itself holds no account data
        if token is not None:
            given = request.headers.get(TOKEN_HEADER, "")
            if not hmac.compare_digest(given.encode(), token.encode()):
                return jsonify(ok=False, message="Access token required"), 401
        if request.method == "GET":
            service.probe()                          # reads never present a dead connection as live
        return None

    @app.after_request
    def no_store(resp):
        resp.headers["Cache-Control"] = "no-store"
        resp.headers["Pragma"] = "no-cache"
        return resp

    @app.errorhandler(Exception)
    def bridge_error(exc):
        if isinstance(exc, HTTPException):
            return jsonify(ok=False, message=exc.name), exc.code
        app.logger.error("bridge error: %s", type(exc).__name__)   # type only: no payloads, no headers
        return jsonify(ok=False, message="Trade Me bridge error"), 500

    @app.get("/")
    def index():
        return send_from_directory(STATIC, "index.html")

    @app.get("/sw.js")
    def service_worker():
        resp = send_from_directory(STATIC, "sw.js")
        resp.headers["Service-Worker-Allowed"] = "/"
        resp.headers["Cache-Control"] = "no-cache"
        return resp

    @app.get("/manifest.webmanifest")
    def manifest():
        return send_from_directory(STATIC, "manifest.webmanifest")

    @app.get("/api/home")
    def home():
        m = service.monitor()
        active = [service.setup_payload(s) for s in service.queue.pending()]
        return jsonify(connection=service.connection, stale=service.is_stale(), freshness=service.freshness(),
                       monitor=m, active_setups=active,
                       last_scan_at=service.last_scan_at.isoformat() if service.last_scan_at else None)

    @app.post("/api/scan")            # user tapped refresh: exactly one scan
    def scan():
        if service.connection["state"] != "CONNECTED":
            service.connect()
        service.scan()
        return jsonify(ok=True, connection=service.connection, freshness=service.freshness())

    @app.get("/api/markets")
    def markets():
        return jsonify(service.markets())

    @app.get("/api/setups")
    def setups():
        return jsonify(service.setups())

    @app.post("/api/setups/<setup_id>/approve")
    def approve(setup_id):
        return jsonify(service.approve(setup_id))

    @app.post("/api/setups/<setup_id>/reject")
    def reject(setup_id):
        return jsonify(service.reject(setup_id))

    @app.get("/api/trades")
    def trades():
        return jsonify(service.monitor())

    @app.get("/api/settings")
    def settings():
        return jsonify({**service.settings(), "notifications": service.notification_settings()})

    @app.get("/api/health")
    def health():
        return jsonify(service.health())

    @app.get("/api/journal")
    def journal():
        try:
            limit = int(request.args.get("limit", "100"))
        except ValueError:
            limit = 100
        return jsonify(service.journal_payload(limit))

    @app.get("/api/audit")
    def audit():
        try:
            limit = int(request.args.get("limit", "100"))
        except ValueError:
            limit = 100
        return jsonify({"records": service.audit.recent(max(1, min(limit, 500)))})

    @app.get("/api/ai/context")
    def ai_context():
        return jsonify(service.ai_context())

    @app.get("/api/safety")
    def safety():
        return jsonify({"kill_switch": service.kill_switch, "execution_enabled": False})

    @app.post("/api/safety/kill-switch")
    def kill_switch():
        body = request.get_json(silent=True) or {}
        return jsonify(service.set_kill_switch(bool(body.get("enabled"))))

    @app.post("/api/replay")
    def replay():
        return jsonify(service.replay(request.get_json(silent=True) or {}))

    @app.get("/api/multi")
    def multi():
        return jsonify(service.multi_analysis())

    @app.get("/api/history")
    def history():
        try:
            days = int(request.args.get("days", "7"))
        except ValueError:
            days = 7
        return jsonify(service.history(days))

    @app.get("/api/push/public-key")
    def push_public_key():
        return jsonify({"configured": bool(os.environ.get("TRADE_ME_VAPID_PUBLIC_KEY")),
                        "public_key": os.environ.get("TRADE_ME_VAPID_PUBLIC_KEY")})

    @app.post("/api/push/subscribe")
    def push_subscribe():
        return jsonify(service.register_push(request.get_json(silent=True) or {}))

    @app.post("/api/push/unsubscribe")
    def push_unsubscribe():
        body = request.get_json(silent=True) or {}
        return jsonify(service.unregister_push(body.get("endpoint", "")))

    return app

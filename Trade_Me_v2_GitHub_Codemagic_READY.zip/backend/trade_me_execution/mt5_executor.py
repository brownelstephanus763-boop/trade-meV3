"""Quarantined MT5 order sender for a possible FUTURE phase.

Guards (all must hold): the executor was explicitly constructed with enabled=True, and the
setup is APPROVED by the user through ApprovalQueue and has no blocking reasons.
It does one thing: send a single order for one approved setup when a human calls it.
There is no loop, scheduler or thread here, and no modify/close code.
"""
from trade_me.models import Signal, TradeSetup


class ExecutionDisabledError(RuntimeError):
    pass


class ExecutionRefused(RuntimeError):
    pass


class MT5Executor:
    def __init__(self, mt5_module, enabled: bool = False, deviation: int = 20, magic: int = 740001):
        self._mt5 = mt5_module
        self.enabled = enabled
        self.deviation = deviation
        self.magic = magic

    def execute_approved(self, setup: TradeSetup):
        if not self.enabled:
            raise ExecutionDisabledError("Execution is disabled in this version")
        if not setup.is_executable:
            raise ExecutionRefused(f"Setup {setup.setup_id} is {setup.status.value}, not an approved executable setup")
        if setup.stop_loss is None or setup.take_profit is None or setup.position_size <= 0:
            raise ExecutionRefused("Setup is missing stop loss, take profit or size")
        buy = setup.signal == Signal.BUY
        request = {
            "action": self._mt5.TRADE_ACTION_DEAL, "symbol": setup.symbol,
            "volume": setup.position_size,
            "type": self._mt5.ORDER_TYPE_BUY if buy else self._mt5.ORDER_TYPE_SELL,
            "price": setup.entry, "sl": setup.stop_loss, "tp": setup.take_profit,
            "deviation": self.deviation, "magic": self.magic, "comment": f"Trade Me {setup.setup_id}"[:31],
            "type_time": self._mt5.ORDER_TIME_GTC, "type_filling": self._mt5.ORDER_FILLING_RETURN,
        }
        return self._mt5.order_send(request)

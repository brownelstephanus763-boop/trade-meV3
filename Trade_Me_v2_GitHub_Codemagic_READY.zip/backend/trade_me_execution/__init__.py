"""SEPARATE, DISABLED-BY-DEFAULT execution package.

The analysis package (trade_me) must never import this package.
Nothing in this repository instantiates the executor with enabled=True.
"""

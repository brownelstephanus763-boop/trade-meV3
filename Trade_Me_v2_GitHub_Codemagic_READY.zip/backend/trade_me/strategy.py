"""Environment-backed strategy configuration.

Defaults remain identical to EngineConfig. Only explicitly supplied environment
variables override a value, so existing deployments keep their behaviour.
"""
import os
from dataclasses import fields, replace
from .models import EngineConfig


def _cast(value, typ):
    if typ is int:
        return int(value)
    if typ is float:
        return float(value)
    if typ is bool:
        return value.strip().lower() in {"1", "true", "yes", "on"}
    return value


def config_from_env(base: EngineConfig | None = None) -> EngineConfig:
    cfg = base or EngineConfig()
    changes = {}
    for f in fields(cfg):
        key = "TRADE_ME_" + f.name.upper()
        raw = os.environ.get(key)
        if raw is not None:
            try:
                changes[f.name] = _cast(raw, f.type if f.type in (int, float, bool, str) else type(getattr(cfg, f.name)))
            except (TypeError, ValueError):
                continue
    return replace(cfg, **changes) if changes else cfg

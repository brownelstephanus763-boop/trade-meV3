"""Human-readable "Why this trade?" text. Formatting only; no decisions, no I/O."""
from .models import SetupStatus, TradeSetup


def _p(v):
    return "n/a" if v is None else f"{v:.5f}"


def _words(name):
    return name.replace("_", " ").capitalize()


def format_alert(s: TradeSetup) -> str:
    """One-line alert."""
    tail = " [BLOCKED: do not trade]" if s.status == SetupStatus.BLOCKED else ""
    return (f"Potential {s.signal.value} setup on {s.symbol} for your review: entry {_p(s.entry)}, "
            f"SL {_p(s.stop_loss)}, TP {_p(s.take_profit)}{tail}")


def format_setup(s: TradeSetup) -> str:
    """Full review card including how every number was calculated."""
    loc = s.price_location.value.replace("_", " ").capitalize()
    lines = [
        f"Potential {s.signal.value} setup: {s.symbol} (for your review, not an order)",
        "",
        f"Direction: {s.market_direction.value.capitalize()}",
        f"Phase: {s.market_phase.value.capitalize()}",
        f"Price location: {loc}",
        f"Pattern: {', '.join(_words(x) for x in s.patterns) or 'none'}",
        f"Confirmation: {', '.join(_words(x) for x in s.confirmations) or 'none'}",
        f"Risk: {s.risk_percent:.2f}% (budget {s.risk_amount:.2f})",
        f"Reward/Risk: 1:{s.reward_risk:g}",
        "",
        f"Entry: {_p(s.entry)}   Stop loss: {_p(s.stop_loss)}   Take profit: {_p(s.take_profit)}",
        f"Suggested size: {s.position_size:g} lots",
        f"Fair value area: {_p(s.value_low)} - {_p(s.value_high)} (mid {_p(s.fair_value)})",
        f"Spread: {s.spread_status} ({s.spread_points:g} pts)   Daily loss: {s.daily_loss_status}   "
        f"Open positions: {s.open_positions_status}",
        f"Status: {s.status.value}",
    ]
    if s.blocked_reasons:
        lines += ["", "BLOCKED, this setup should not be traded:"] + [f"- {r}" for r in s.blocked_reasons]
    lines += ["", "Why this setup:", s.reason, "",
              "How the levels were calculated:"] + [f"- {c}" for c in s.calculation]
    lines += ["", "This is an analysis result, not a prediction. Any trade can lose. The decision is yours."]
    return "\n".join(lines)

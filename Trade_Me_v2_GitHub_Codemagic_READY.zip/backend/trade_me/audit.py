"""Audit facade. Audit records are informational and never control execution."""
from .journal import DecisionJournal


class AuditTrail:
    def __init__(self, journal: DecisionJournal):
        self.journal = journal

    def record(self, event_type: str, **data):
        return self.journal.append({"event_type": event_type, **data})

    def recent(self, limit=100):
        return self.journal.recent(limit)

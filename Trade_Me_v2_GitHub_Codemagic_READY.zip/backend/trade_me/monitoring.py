"""Read-only monitoring: open positions, P/L, account and history.
Informational only. No closing, modifying, or SL/TP management exists here."""
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional

from .models import AccountState


@dataclass
class PositionInfo:
    ticket: int
    symbol: str
    side: str                       # BUY / SELL
    volume: float
    open_price: float
    current_price: float
    sl: Optional[float]
    tp: Optional[float]
    profit: float
    open_time: Optional[datetime] = None


@dataclass
class DealInfo:
    ticket: int
    symbol: str
    side: str
    volume: float
    price: float
    profit: float                   # profit + commission + swap
    time: datetime


@dataclass
class MonitorSnapshot:
    balance: float
    equity: float
    floating_pl: float
    realized_pl_today: float
    daily_loss_percent: float
    positions: list[PositionInfo] = field(default_factory=list)
    history: list[DealInfo] = field(default_factory=list)

    def to_account_state(self) -> AccountState:
        return AccountState(equity=self.equity, balance=self.balance,
                            daily_loss_percent=self.daily_loss_percent,
                            open_positions=len(self.positions))


def daily_loss_percent(balance: float, realized_today: float, floating: float) -> float:
    """Loss today as % of the estimated start-of-day balance (0 when the day is net positive)."""
    start = balance - realized_today
    if start <= 0:
        return 0.0
    net = realized_today + floating
    return max(0.0, -net) / start * 100


class AccountMonitor:
    """Reads state from a data feed. Only calls the feed's read-only methods."""

    def __init__(self, feed):
        self._feed = feed

    def snapshot(self, day_start: Optional[datetime] = None, day_end: Optional[datetime] = None) -> MonitorSnapshot:
        acct = self._feed.account()
        positions = self._feed.positions()
        history = self._feed.history_deals(day_start, day_end) if day_start and day_end else []
        floating = sum(p.profit for p in positions)
        realized = sum(d.profit for d in history)
        return MonitorSnapshot(
            balance=acct["balance"], equity=acct["equity"], floating_pl=floating,
            realized_pl_today=realized,
            daily_loss_percent=daily_loss_percent(acct["balance"], realized, floating),
            positions=positions, history=history)

"""Deterministic analysis engine.

analyze()       -> Analysis   (pure function of the candles + config)
build_setup()   -> TradeSetup (a PROPOSAL for the user to review; never an order)

This module imports no broker/execution code and cannot place, close or modify trades.
"""
import hashlib
import math
from typing import Optional

import pandas as pd

from .math_tools import (atr, bullish_engulfing, bearish_engulfing, bullish_rejection,
                         bearish_rejection, find_double_bottom, find_double_top,
                         last_swing_levels, detect_swing_break, trend_from_swings)
from .models import (AccountState, Analysis, Direction, EngineConfig, Phase, PriceLocation,
                     Signal, SetupStatus, SymbolSpec, TradeSetup)
from .risk import assess_risk, reward_risk_ratio


def _pretty(names):
    return ", ".join(n.replace("_", " ").lower() for n in names)


def _last_timestamp(candles: pd.DataFrame):
    for col in ("time", "timestamp"):
        if col in candles.columns:
            return candles[col].iloc[-1]
    if isinstance(candles.index, pd.DatetimeIndex):
        return candles.index[-1]
    return None


class TradeMeEngine:
    def __init__(self, config: Optional[EngineConfig] = None):
        self.cfg = config or EngineConfig()

    # ------------------------------------------------------------ analysis
    def analyze(self, candles: pd.DataFrame) -> Analysis:
        """Analyse COMPLETED candles (last row = last completed candle). Pure and deterministic."""
        required = {"open", "high", "low", "close"}
        missing = required - set(candles.columns)
        if missing:
            raise ValueError(f"Missing columns: {sorted(missing)}")
        cfg = self.cfg
        df = candles.copy().reset_index(drop=True)
        result = Analysis()
        minimum = max(cfg.atr_long, cfg.box_length) + 5
        if len(df) < minimum:
            result.reason = "Not enough candles"
            return result
        df["atr_s"] = atr(df, cfg.atr_short)
        df["atr_l"] = atr(df, cfg.atr_long)
        a = float(df["atr_l"].iloc[-1])
        a_short = float(df["atr_s"].iloc[-1])
        if not math.isfinite(a) or not math.isfinite(a_short) or a <= 0:
            result.reason = "Volatility data not ready"
            return result

        # Value area = the previous COMPLETED range (excludes the candle being evaluated).
        box = df.iloc[-1 - cfg.box_length:-1]
        high, low = float(box.high.max()), float(box.low.min())
        fair = (high + low) / 2
        result.atr = a
        result.fair_value, result.value_low, result.value_high = fair, low, high
        close = float(df.close.iloc[-1])
        result.close = close
        result.candle_high = float(df.high.iloc[-1])
        result.candle_low = float(df.low.iloc[-1])

        contraction_ratio = a_short / a
        normalized_width = (high - low) / a
        result.contraction = (contraction_ratio <= cfg.contraction_ratio_max
                              and normalized_width <= cfg.box_atr_max)
        result.price_below_value = close < fair
        result.price_above_value = close > fair
        result.price_location = (PriceLocation.BELOW_FAIR_VALUE if close < fair else
                                 PriceLocation.ABOVE_FAIR_VALUE if close > fair else
                                 PriceLocation.AT_FAIR_VALUE)
        buf = a * cfg.expansion_buffer_atr
        result.expansion = close > high + buf or close < low - buf

        k = min(3, len(df) - 1)
        move = (close - float(df.close.iloc[-1 - k])) / a
        result.displacement_atr = move
        result.displacement = abs(move) >= cfg.displacement_atr_multiple

        trend = trend_from_swings(df, cfg.swing_left, cfg.swing_right)
        result.direction = Direction(trend)
        if result.expansion:
            result.phase = Phase.EXPANSION
        elif result.contraction:
            result.phase = Phase.CONTRACTION
        elif result.displacement and trend != "NEUTRAL":
            result.phase = Phase.TREND
        else:
            result.phase = Phase.UNKNOWN

        # Structural levels come from candles BEFORE the last one.
        prior = df.iloc[:-1]
        result.last_swing_high, result.last_swing_low = last_swing_levels(
            prior, cfg.swing_left, cfg.swing_right, cfg.stop_swing_lookback)

        cur, prev = df.iloc[-1], df.iloc[-2]
        if bullish_engulfing(prev, cur): result.patterns.append("BULLISH_ENGULFING")
        if bearish_engulfing(prev, cur): result.patterns.append("BEARISH_ENGULFING")
        if bullish_rejection(cur, cfg.rejection_wick_ratio): result.patterns.append("BULLISH_REJECTION")
        if bearish_rejection(cur, cfg.rejection_wick_ratio): result.patterns.append("BEARISH_REJECTION")
        dkw = dict(left=cfg.swing_left, right=cfg.swing_right, lookback=cfg.double_lookback,
                   min_separation=cfg.double_min_separation, min_depth_atr=cfg.double_min_depth_atr)
        if find_double_bottom(df, a, cfg.double_tolerance_atr, **dkw): result.patterns.append("DOUBLE_BOTTOM")
        if find_double_top(df, a, cfg.double_tolerance_atr, **dkw): result.patterns.append("DOUBLE_TOP")

        bull_level, bear_level = detect_swing_break(
            df, a, cfg.swing_left, cfg.swing_right, cfg.swing_break_lookback, cfg.swing_break_buffer_atr)
        if bull_level is not None: result.confirmations.append("BULLISH_SWING_BREAK")
        if bear_level is not None: result.confirmations.append("BEARISH_SWING_BREAK")
        if result.displacement:
            result.confirmations.append("BULLISH_DISPLACEMENT" if move > 0 else "BEARISH_DISPLACEMENT")

        bullish = {"BULLISH_ENGULFING", "BULLISH_REJECTION", "DOUBLE_BOTTOM"}
        bearish = {"BEARISH_ENGULFING", "BEARISH_REJECTION", "DOUBLE_TOP"}
        bull_ok = (len(bullish.intersection(result.patterns)) >= cfg.min_confirmations
                   or "BULLISH_SWING_BREAK" in result.confirmations)
        bear_ok = (len(bearish.intersection(result.patterns)) >= cfg.min_confirmations
                   or "BEARISH_SWING_BREAK" in result.confirmations)
        context_ok = result.expansion or result.displacement or result.phase == Phase.TREND

        if trend == "BULLISH" and result.price_below_value and bull_ok and context_ok:
            names = [p for p in result.patterns if p in bullish] + \
                    [c for c in result.confirmations if c.startswith("BULLISH")]
            result.signal = Signal.BUY
            result.reason = ("Bullish market structure is present, price is below the calculated "
                             f"fair-value area, and bullish confirmation has appeared ({_pretty(names)}).")
        elif trend == "BEARISH" and result.price_above_value and bear_ok and context_ok:
            names = [p for p in result.patterns if p in bearish] + \
                    [c for c in result.confirmations if c.startswith("BEARISH")]
            result.signal = Signal.SELL
            result.reason = ("Bearish market structure is present, price is above the calculated "
                             f"fair-value area, and bearish confirmation has appeared ({_pretty(names)}).")
        else:
            result.signal = Signal.WAIT
            result.reason = "Context or entry confirmation not complete"
        return result

    # ---------------------------------------------------------- proposals
    def propose_setup(self, symbol: str, candles: pd.DataFrame, account: AccountState,
                      spec: Optional[SymbolSpec] = None, spread_points: float = 0.0,
                      entry: Optional[float] = None) -> Optional[TradeSetup]:
        """Analyse and, if a potential BUY/SELL exists, return a TradeSetup for review.
        Returns None for WAIT. Never sends anything anywhere."""
        analysis = self.analyze(candles)
        return self.build_setup(symbol, analysis, account, spec, spread_points, entry,
                                timestamp=_last_timestamp(candles), n_candles=len(candles))

    def build_setup(self, symbol: str, analysis: Analysis, account: AccountState,
                    spec: Optional[SymbolSpec] = None, spread_points: float = 0.0,
                    entry: Optional[float] = None, timestamp=None,
                    n_candles: int = 0) -> Optional[TradeSetup]:
        if analysis.signal not in (Signal.BUY, Signal.SELL):
            return None
        cfg = self.cfg
        spec = spec or SymbolSpec(symbol=symbol)
        buy = analysis.signal == Signal.BUY
        a = analysis.atr
        calc = []

        # ---- entry
        if entry is None:
            entry = analysis.close
            calc.append(f"Entry = {entry:.5f} (close of the last completed candle; the real fill may differ by spread/slippage)")
        else:
            calc.append(f"Entry = {entry:.5f} (price supplied by the caller)")
        calc.append(f"ATR({cfg.atr_long}) = {a:.5f}")

        # ---- stop loss: structural level +/- ATR buffer
        if buy:
            cands = [x for x in (analysis.last_swing_low, analysis.candle_low) if x is not None]
            structural = min(cands)
            calc.append(f"Structural low = min(last swing low {analysis.last_swing_low if analysis.last_swing_low is None else format(analysis.last_swing_low, '.5f')}, "
                        f"signal candle low {analysis.candle_low:.5f}) = {structural:.5f}")
            stop = structural - cfg.stop_atr_buffer * a
            calc.append(f"Stop loss = structural low - {cfg.stop_atr_buffer:g} x ATR = {stop:.5f}")
            side_ok = stop < entry
        else:
            cands = [x for x in (analysis.last_swing_high, analysis.candle_high) if x is not None]
            structural = max(cands)
            calc.append(f"Structural high = max(last swing high {analysis.last_swing_high if analysis.last_swing_high is None else format(analysis.last_swing_high, '.5f')}, "
                        f"signal candle high {analysis.candle_high:.5f}) = {structural:.5f}")
            stop = structural + cfg.stop_atr_buffer * a
            calc.append(f"Stop loss = structural high + {cfg.stop_atr_buffer:g} x ATR = {stop:.5f}")
            side_ok = stop > entry

        reasons = []
        if side_ok:
            stop_distance = abs(entry - stop)
            calc.append(f"Stop distance = |entry - stop loss| = {stop_distance:.5f}")
            take_profit = entry + cfg.reward_risk * stop_distance if buy else entry - cfg.reward_risk * stop_distance
            calc.append(f"Take profit = entry {'+' if buy else '-'} {cfg.reward_risk:g} x stop distance = {take_profit:.5f}")
            rr = reward_risk_ratio(entry, stop, take_profit)
        else:
            stop_distance, take_profit, rr = 0.0, None, 0.0
            reasons.append("Invalid stop: stop loss is not beyond the entry price")
            calc.append("Stop loss is not on the protective side of the entry: setup blocked")

        # ---- risk engine
        ra = assess_risk(
            account.equity, cfg.risk_percent, stop_distance, spec.value_per_price_unit,
            spread_points, cfg.max_spread_points, account.daily_loss_percent,
            cfg.max_daily_loss_percent, account.open_positions, cfg.max_open_positions,
            spec.min_volume, spec.max_volume, spec.volume_step)
        calc.append(f"Risk budget = equity {account.equity:.2f} x {cfg.risk_percent:g}% = {ra.risk_amount:.2f}")
        calc.append(f"Position size = floor(budget / (stop distance x {spec.value_per_price_unit:g}) / {spec.volume_step:g}) x {spec.volume_step:g} = {ra.position_size:g} lots")
        for r in ra.blocked_reasons:
            if side_ok or not r.startswith("Invalid position size"):
                reasons.append(r)

        ts = timestamp
        key = f"{symbol}|{ts if ts is not None else n_candles}|{analysis.signal.value}|{entry:.10f}"
        setup_id = f"{symbol}-{analysis.signal.value}-{hashlib.sha1(key.encode()).hexdigest()[:10]}"
        return TradeSetup(
            setup_id=setup_id, symbol=symbol, timestamp=ts,
            direction=Direction.BULLISH if buy else Direction.BEARISH, signal=analysis.signal,
            entry=entry, stop_loss=stop if side_ok else None, take_profit=take_profit,
            stop_distance=stop_distance, risk_percent=cfg.risk_percent,
            risk_amount=ra.risk_amount, position_size=ra.position_size if side_ok else 0.0,
            reward_risk=rr, market_direction=analysis.direction, market_phase=analysis.phase,
            fair_value=analysis.fair_value, value_low=analysis.value_low,
            value_high=analysis.value_high, price_location=analysis.price_location,
            patterns=list(analysis.patterns), confirmations=list(analysis.confirmations),
            reason=analysis.reason,
            status=SetupStatus.BLOCKED if reasons else SetupStatus.WAITING,
            spread_points=spread_points,
            spread_status="OK" if ra.spread_ok else "BLOCKED",
            daily_loss_status="OK" if ra.daily_loss_ok else "BLOCKED",
            open_positions_status="OK" if ra.open_positions_ok else "BLOCKED",
            blocked_reasons=reasons, calculation=calc)

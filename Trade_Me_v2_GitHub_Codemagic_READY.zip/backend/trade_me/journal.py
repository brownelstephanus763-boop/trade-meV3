"""Small JSONL decision journal. Durable, append-only, and independent of broker execution."""
import json
from datetime import datetime, timezone
from pathlib import Path


class DecisionJournal:
    def __init__(self, path: str | Path = "data/decision_journal.jsonl"):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def append(self, event: dict) -> dict:
        row = {"recorded_at": datetime.now(timezone.utc).isoformat(), **event}
        with self.path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(row, ensure_ascii=False, default=str) + "\n")
        return row

    def recent(self, limit: int = 100) -> list[dict]:
        if not self.path.exists():
            return []
        rows = []
        with self.path.open("r", encoding="utf-8") as f:
            for line in f:
                try:
                    rows.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
        return rows[-max(1, int(limit)):][::-1]

    def count_today(self, event_type: str | None = None) -> int:
        today = datetime.now(timezone.utc).date().isoformat()
        return sum(1 for r in self.recent(10000)
                   if str(r.get("recorded_at", "")).startswith(today)
                   and (event_type is None or r.get("event_type") == event_type))

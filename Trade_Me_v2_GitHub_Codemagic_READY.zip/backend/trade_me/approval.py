"""Manual approval layer. Only a human-triggered call can move a setup to APPROVED.

There are no timers, no auto-approve and no bulk-approve. A BUY/SELL signal is never approval.
Approving does not send anything to a broker; it only marks the setup as approved.
"""
from datetime import datetime, timezone
from typing import Optional

from .models import SetupStatus, TradeSetup


class ApprovalError(Exception):
    pass


def _now():
    return datetime.now(timezone.utc)


class ApprovalQueue:
    def __init__(self):
        self._setups: dict[str, TradeSetup] = {}

    def submit(self, setup: TradeSetup) -> TradeSetup:
        """Register a proposed setup. Idempotent: an already-known setup_id is NOT reset,
        so a rejected/expired setup cannot come back as WAITING by re-scanning."""
        existing = self._setups.get(setup.setup_id)
        if existing is not None:
            return existing
        if setup.status not in (SetupStatus.WAITING, SetupStatus.BLOCKED):
            raise ApprovalError("Only WAITING or BLOCKED setups can be submitted")
        self._setups[setup.setup_id] = setup
        return setup

    def get(self, setup_id: str) -> TradeSetup:
        try:
            return self._setups[setup_id]
        except KeyError:
            raise ApprovalError(f"Unknown setup: {setup_id}")

    def all(self) -> list[TradeSetup]:
        return list(self._setups.values())

    def pending(self) -> list[TradeSetup]:
        return [s for s in self._setups.values() if s.status == SetupStatus.WAITING]

    def _decide(self, setup_id, new_status, note, now) -> TradeSetup:
        s = self.get(setup_id)
        if s.status == SetupStatus.BLOCKED:
            raise ApprovalError(f"Setup {setup_id} is BLOCKED by risk checks: {'; '.join(s.blocked_reasons)}")
        if s.status != SetupStatus.WAITING:
            raise ApprovalError(f"Setup {setup_id} is {s.status.value}; only WAITING setups can be decided")
        s.status = new_status
        s.decided_at = now or _now()
        s.decision_note = note
        return s

    def approve(self, setup_id: str, note: str = "", now: Optional[datetime] = None) -> TradeSetup:
        return self._decide(setup_id, SetupStatus.APPROVED, note, now)

    def reject(self, setup_id: str, note: str = "", now: Optional[datetime] = None) -> TradeSetup:
        return self._decide(setup_id, SetupStatus.REJECTED, note, now)

    def expire(self, setup_id: str, note: str = "", now: Optional[datetime] = None) -> TradeSetup:
        """Explicit, user/UI-initiated only. Nothing in this package expires setups by itself."""
        return self._decide(setup_id, SetupStatus.EXPIRED, note, now)

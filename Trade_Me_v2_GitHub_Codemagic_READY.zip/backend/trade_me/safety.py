"""Process/file-backed safety state. Kill switch only blocks approvals; it never sends orders."""
import json
from pathlib import Path
from datetime import datetime, timezone


class SafetyState:
    def __init__(self, path="data/safety_state.json"):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.enabled = self._load()

    def _load(self):
        try:
            return bool(json.loads(self.path.read_text(encoding="utf-8")).get("kill_switch", False))
        except (FileNotFoundError, ValueError, OSError):
            return False

    def set(self, enabled: bool):
        self.enabled = bool(enabled)
        self.path.write_text(json.dumps({"kill_switch": self.enabled,
                                         "changed_at": datetime.now(timezone.utc).isoformat()}), encoding="utf-8")
        return self.enabled

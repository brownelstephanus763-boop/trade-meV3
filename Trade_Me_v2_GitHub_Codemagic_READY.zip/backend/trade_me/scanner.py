"""Multi-symbol scanner. Each symbol is analysed independently. One call = one scan;
there is no loop, timer or scheduler. It proposes setups; it never executes anything."""
from dataclasses import dataclass
from typing import Iterable, Optional

import pandas as pd

from .engine import TradeMeEngine
from .models import AccountState, Analysis, EngineConfig, SymbolSpec, TradeSetup


@dataclass
class ScanInput:
    symbol: str
    candles: pd.DataFrame
    spec: Optional[SymbolSpec] = None
    spread_points: float = 0.0


@dataclass
class ScanResult:
    symbol: str
    analysis: Optional[Analysis] = None
    setup: Optional[TradeSetup] = None     # a proposal for review, or None (WAIT)
    error: Optional[str] = None


class MarketScanner:
    def __init__(self, config: Optional[EngineConfig] = None,
                 symbol_configs: Optional[dict[str, EngineConfig]] = None):
        self.config = config or EngineConfig()
        self.symbol_configs = symbol_configs or {}

    def _engine(self, symbol: str) -> TradeMeEngine:
        return TradeMeEngine(self.symbol_configs.get(symbol, self.config))

    def scan(self, inputs: Iterable[ScanInput], account: AccountState, queue=None) -> list[ScanResult]:
        """Analyse every input independently. If a queue is given, proposed setups are
        submitted as WAITING/BLOCKED: submitting is not approving."""
        results = []
        for item in inputs:
            try:
                engine = self._engine(item.symbol)
                analysis = engine.analyze(item.candles)
                setup = engine.build_setup(
                    item.symbol, analysis, account, item.spec, item.spread_points,
                    timestamp=_ts(item.candles), n_candles=len(item.candles))
                if setup is not None and queue is not None:
                    setup = queue.submit(setup)
                results.append(ScanResult(item.symbol, analysis, setup))
            except ValueError as exc:      # bad data for ONE symbol must not affect the others
                results.append(ScanResult(item.symbol, error=str(exc)))
            except Exception as exc:       # any other failure in ONE symbol is contained the same way
                results.append(ScanResult(item.symbol, error=f"Analysis failed ({type(exc).__name__})"))
        return results

    def scan_feed(self, feed, symbols: Iterable[str], timeframe, account: AccountState,
                  count: int = 300, queue=None) -> list[ScanResult]:
        """Read candles/spec/spread for each symbol from a read-only data feed, then scan."""
        inputs = [ScanInput(s, feed.rates(s, timeframe, count), feed.symbol_spec(s), feed.spread_points(s))
                  for s in symbols]
        return self.scan(inputs, account, queue)


def _ts(candles):
    from .engine import _last_timestamp
    return _last_timestamp(candles)

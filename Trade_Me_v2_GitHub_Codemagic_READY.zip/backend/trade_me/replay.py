"""Offline replay/backtest helper. It calls the existing deterministic engine only."""
from dataclasses import dataclass, asdict
import pandas as pd
from .engine import TradeMeEngine
from .models import AccountState, EngineConfig, SymbolSpec


@dataclass
class ReplayResult:
    candle_index: int
    timestamp: str
    signal: str
    direction: str
    phase: str
    close: float
    reason: str
    setup: dict | None


def replay(candles, symbol="EURUSD", config=None, account=None, spec=None, min_candles=80, max_steps=250):
    df = candles.copy()
    if "time" in df.columns:
        df["time"] = pd.to_datetime(df["time"])
    cfg = config or EngineConfig()
    engine = TradeMeEngine(cfg)
    account = account or AccountState(equity=1000.0, balance=1000.0)
    spec = spec or SymbolSpec(symbol=symbol)
    out = []
    start = max(min_candles, cfg.atr_long + cfg.box_length + 5)
    stop = min(len(df), start + max_steps)
    for i in range(start, stop):
        chunk = df.iloc[:i].reset_index(drop=True)
        try:
            analysis = engine.analyze(chunk)
            setup = engine.build_setup(symbol, analysis, account, spec,
                                       timestamp=chunk.iloc[-1]["time"] if "time" in chunk else i,
                                       n_candles=len(chunk))
            out.append(asdict(ReplayResult(
                i, str(chunk.iloc[-1]["time"] if "time" in chunk else i),
                analysis.signal.value, analysis.direction.value, analysis.phase.value,
                float(analysis.close or 0), analysis.reason,
                {"signal": setup.signal.value, "entry": setup.entry, "stop_loss": setup.stop_loss,
                 "take_profit": setup.take_profit, "risk_amount": setup.risk_amount,
                 "position_size": setup.position_size, "reward_risk": setup.reward_risk}
                if setup else None)))
        except Exception as exc:
            out.append({"candle_index": i, "timestamp": str(i), "signal": "ERROR",
                        "direction": "NEUTRAL", "phase": "UNKNOWN", "close": None,
                        "reason": f"Replay failed ({type(exc).__name__})", "setup": None})
    signals = sum(1 for x in out if x["signal"] in ("BUY", "SELL"))
    return {"symbol": symbol, "steps": len(out), "signals": signals, "results": out}

"""READ-ONLY MetaTrader 5 data feed.

Only market-data and account-information calls are used here. This module contains no
order/trade calls at all; tests/test_architecture.py enforces that with a whitelist.
"""
from datetime import datetime
from typing import Optional

import pandas as pd

from .models import SymbolSpec
from .monitoring import DealInfo, PositionInfo


class MT5DataFeed:
    def __init__(self, mt5_module=None):
        self._mt5 = mt5_module          # injectable for tests

    # ---- connection
    def connect(self, path=None, login=None, password=None, server=None) -> bool:
        if self._mt5 is None:
            import MetaTrader5 as mt5
            self._mt5 = mt5
        kwargs = {}
        if login is not None: kwargs["login"] = login
        if password is not None: kwargs["password"] = password
        if server is not None: kwargs["server"] = server
        ok = self._mt5.initialize(path, **kwargs) if path else self._mt5.initialize(**kwargs)
        if not ok:
            raise RuntimeError(f"MT5 initialize failed: {self._mt5.last_error()}")
        return True

    def shutdown(self):
        if self._mt5:
            self._mt5.shutdown()

    # ---- market data
    def symbols(self, group="*"):
        return self._mt5.symbols_get(group=group)

    def timeframe(self, name: str):
        """'M15' -> mt5.TIMEFRAME_M15"""
        return getattr(self._mt5, f"TIMEFRAME_{name.upper()}")

    def rates(self, symbol, timeframe, count=1000, include_forming=False) -> pd.DataFrame:
        """OHLC candles as a DataFrame. The still-forming candle is dropped by default so the
        engine only ever sees COMPLETED candles."""
        raw = self._mt5.copy_rates_from_pos(symbol, timeframe, 0, count + (0 if include_forming else 1))
        if raw is None or len(raw) == 0:
            raise ValueError(f"No rates returned for {symbol}")
        df = pd.DataFrame(raw)
        if not include_forming:
            df = df.iloc[:-1]
        if "time" in df.columns:
            df["time"] = pd.to_datetime(df["time"], unit="s")
        if "tick_volume" in df.columns:
            df["volume"] = df["tick_volume"]
        return df.reset_index(drop=True)

    def tick(self, symbol) -> dict:
        t = self._mt5.symbol_info_tick(symbol)
        return {"bid": t.bid, "ask": t.ask, "time": t.time}

    def symbol_spec(self, symbol) -> SymbolSpec:
        i = self._mt5.symbol_info(symbol)
        tick_size = getattr(i, "trade_tick_size", 0) or getattr(i, "point", 0) or 1.0
        tick_value = getattr(i, "trade_tick_value", 0) or 0.0
        vppu = tick_value / tick_size if tick_value else float(getattr(i, "trade_contract_size", 1.0))
        return SymbolSpec(symbol=symbol, value_per_price_unit=vppu, point=i.point,
                          min_volume=i.volume_min, max_volume=i.volume_max, volume_step=i.volume_step)

    def spread_points(self, symbol) -> float:
        return float(self._mt5.symbol_info(symbol).spread)

    # ---- account / monitoring (information only)
    def account(self) -> dict:
        a = self._mt5.account_info()
        return {"balance": a.balance, "equity": a.equity, "profit": a.profit,
                "margin": getattr(a, "margin", 0.0), "currency": getattr(a, "currency", "")}

    def positions(self, symbol: Optional[str] = None) -> list[PositionInfo]:
        raw = self._mt5.positions_get(symbol=symbol) if symbol else self._mt5.positions_get()
        buy_type = getattr(self._mt5, "POSITION_TYPE_BUY", 0)
        out = []
        for p in (raw or []):
            out.append(PositionInfo(
                ticket=p.ticket, symbol=p.symbol, side="BUY" if p.type == buy_type else "SELL",
                volume=p.volume, open_price=p.price_open, current_price=p.price_current,
                sl=p.sl or None, tp=p.tp or None, profit=p.profit,
                open_time=datetime.fromtimestamp(p.time) if getattr(p, "time", None) else None))
        return out

    def history_deals(self, date_from: datetime, date_to: datetime) -> list[DealInfo]:
        raw = self._mt5.history_deals_get(date_from, date_to)
        buy_type = getattr(self._mt5, "DEAL_TYPE_BUY", 0)
        sell_type = getattr(self._mt5, "DEAL_TYPE_SELL", 1)
        out = []
        for d in (raw or []):
            if d.type not in (buy_type, sell_type):
                continue                       # skip balance/credit/etc. entries
            out.append(DealInfo(
                ticket=d.ticket, symbol=d.symbol, side="BUY" if d.type == buy_type else "SELL",
                volume=d.volume, price=d.price, profit=d.profit + getattr(d, "commission", 0.0)
                + getattr(d, "swap", 0.0), time=datetime.fromtimestamp(d.time)))
        return out

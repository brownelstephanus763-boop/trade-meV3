"""Deterministic indicator and pattern helpers. Pure functions, no I/O, no randomness."""
import math
from dataclasses import dataclass
from typing import Optional

import pandas as pd


# ---------------------------------------------------------------- volatility
def true_range(df):
    prev = df["close"].shift(1)
    return pd.concat([
        df["high"] - df["low"],
        (df["high"] - prev).abs(),
        (df["low"] - prev).abs(),
    ], axis=1).max(axis=1)


def atr(df, period):
    return true_range(df).rolling(period, min_periods=period).mean()


# ------------------------------------------------------------ candle shapes
def candle_range(c):
    return max(float(c["high"] - c["low"]), 1e-12)


def upper_wick(c):
    return float(c["high"] - max(c["open"], c["close"]))


def lower_wick(c):
    return float(min(c["open"], c["close"]) - c["low"])


def bullish_engulfing(prev, cur):
    return bool(prev["close"] < prev["open"] and cur["close"] > cur["open"]
                and cur["open"] <= prev["close"] and cur["close"] >= prev["open"])


def bearish_engulfing(prev, cur):
    return bool(prev["close"] > prev["open"] and cur["close"] < cur["open"]
                and cur["open"] >= prev["close"] and cur["close"] <= prev["open"])


def bullish_rejection(c, wick_ratio):
    r = candle_range(c)
    return bool(c["close"] > c["open"] and lower_wick(c) / r >= wick_ratio
                and c["close"] >= c["low"] + r * 0.60)


def bearish_rejection(c, wick_ratio):
    r = candle_range(c)
    return bool(c["close"] < c["open"] and upper_wick(c) / r >= wick_ratio
                and c["close"] <= c["low"] + r * 0.40)


# ------------------------------------------------------------------- swings
def _collapse(indices, values, keep_max, min_separation):
    """Merge swing points closer than min_separation, keeping the more extreme one."""
    out = []
    for i in indices:
        if out and i - out[-1] < min_separation:
            prev = out[-1]
            better = values[i] > values[prev] if keep_max else values[i] < values[prev]
            if better:
                out[-1] = i
        else:
            out.append(i)
    return out


def local_swings(df, left, right):
    """Indices of confirmed swing highs and lows (needs `right` candles after each)."""
    highs, lows = [], []
    for i in range(left, len(df) - right):
        h = df["high"].iloc[i]
        l = df["low"].iloc[i]
        window_h = df["high"].iloc[i - left:i + right + 1]
        window_l = df["low"].iloc[i - left:i + right + 1]
        if h >= window_h.max():
            highs.append(i)
        if l <= window_l.min():
            lows.append(i)
    # flat tops/bottoms produce adjacent tied swings: keep only the first of each tie
    gap = max(left, right) + 1
    return (_collapse(highs, df["high"], True, gap), _collapse(lows, df["low"], False, gap))


def trend_from_swings(df, left, right):
    highs, lows = local_swings(df, left, right)
    if len(highs) < 2 or len(lows) < 2:
        return "NEUTRAL"
    h1, h2 = df["high"].iloc[highs[-2]], df["high"].iloc[highs[-1]]
    l1, l2 = df["low"].iloc[lows[-2]], df["low"].iloc[lows[-1]]
    if h2 > h1 and l2 > l1:
        return "BULLISH"
    if h2 < h1 and l2 < l1:
        return "BEARISH"
    return "NEUTRAL"


def last_swing_levels(df, left, right, lookback):
    """Latest confirmed swing high / low price within `lookback` candles of the end of df.

    Returns (swing_high_or_None, swing_low_or_None). Pass candles that EXCLUDE the
    candle currently being evaluated, so a candle can never hide the swing it breaks.
    """
    highs, lows = local_swings(df, left, right)
    n = len(df)
    first = n - lookback
    hi = next((float(df["high"].iloc[i]) for i in reversed(highs) if i >= first), None)
    lo = next((float(df["low"].iloc[i]) for i in reversed(lows) if i >= first), None)
    return hi, lo


def detect_swing_break(df, atr_value, left, right, lookback, buffer_atr):
    """Fresh close beyond the latest confirmed swing level (structure break).

    The swing levels come from all candles BEFORE the last one; the last candle must
    close beyond level +/- buffer while the candle before it had not.
    Returns (bullish_level_or_None, bearish_level_or_None).
    """
    if len(df) < left + right + 3 or not math.isfinite(atr_value) or atr_value <= 0:
        return None, None
    prior = df.iloc[:-1]
    hi, lo = last_swing_levels(prior, left, right, lookback)
    close = float(df["close"].iloc[-1])
    prev_close = float(df["close"].iloc[-2])
    buf = atr_value * buffer_atr
    bull = hi if (hi is not None and close > hi + buf and prev_close <= hi + buf) else None
    bear = lo if (lo is not None and close < lo - buf and prev_close >= lo - buf) else None
    return bull, bear


# ----------------------------------------------------- double top / bottom
@dataclass(frozen=True)
class DoublePattern:
    first_index: int
    second_index: int
    first_level: float
    second_level: float
    middle_level: float   # trough between two tops / peak between two bottoms


def find_double_top(df, atr_value, tolerance_atr, left=2, right=2, lookback=60,
                    min_separation=3, min_depth_atr=0.5) -> Optional[DoublePattern]:
    """Last two confirmed swing highs at (almost) the same level with a real pullback
    between them, no higher high since, and price now closing below both tops."""
    if len(df) < 8 or not math.isfinite(atr_value) or atr_value <= 0:
        return None
    highs, _ = local_swings(df, left, right)
    n = len(df)
    highs = _collapse([i for i in highs if i >= n - lookback], df["high"], True, min_separation)
    if len(highs) < 2:
        return None
    i1, i2 = highs[-2], highs[-1]
    a, b = float(df["high"].iloc[i1]), float(df["high"].iloc[i2])
    tol = atr_value * tolerance_atr
    if abs(a - b) > tol:
        return None
    trough = float(df["low"].iloc[i1 + 1:i2].min())
    if min(a, b) - trough < atr_value * min_depth_atr:
        return None
    if float(df["high"].iloc[i2 + 1:].max()) > max(a, b) + tol:
        return None
    if not float(df["close"].iloc[-1]) < min(a, b):
        return None
    return DoublePattern(i1, i2, a, b, trough)


def find_double_bottom(df, atr_value, tolerance_atr, left=2, right=2, lookback=60,
                       min_separation=3, min_depth_atr=0.5) -> Optional[DoublePattern]:
    """Mirror of find_double_top for swing lows."""
    if len(df) < 8 or not math.isfinite(atr_value) or atr_value <= 0:
        return None
    _, lows = local_swings(df, left, right)
    n = len(df)
    lows = _collapse([i for i in lows if i >= n - lookback], df["low"], False, min_separation)
    if len(lows) < 2:
        return None
    i1, i2 = lows[-2], lows[-1]
    a, b = float(df["low"].iloc[i1]), float(df["low"].iloc[i2])
    tol = atr_value * tolerance_atr
    if abs(a - b) > tol:
        return None
    peak = float(df["high"].iloc[i1 + 1:i2].max())
    if peak - max(a, b) < atr_value * min_depth_atr:
        return None
    if float(df["low"].iloc[i2 + 1:].min()) < min(a, b) - tol:
        return None
    if not float(df["close"].iloc[-1]) > max(a, b):
        return None
    return DoublePattern(i1, i2, a, b, peak)


def double_top(df, atr_value, tolerance_atr, **kwargs):
    return find_double_top(df, atr_value, tolerance_atr, **kwargs) is not None


def double_bottom(df, atr_value, tolerance_atr, **kwargs):
    return find_double_bottom(df, atr_value, tolerance_atr, **kwargs) is not None

"""Additional portfolio-level safety policy for Trade Me.

This layer only blocks analysis approval. It never places or modifies orders.
"""
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Iterable


@dataclass(frozen=True)
class RiskPolicy:
    max_daily_approvals: int = 5
    max_total_position_volume: float = 3.0
    max_symbol_positions: int = 1
    max_stop_atr_multiple: float = 5.0
    max_currency_exposure_units: float = 3.0


def _currency_exposure(symbol: str, side: str, volume: float) -> dict[str, float]:
    """Simple exposure proxy for FX symbols such as EURUSD.

    It deliberately treats each lot as one exposure unit; broker-specific contract
    valuation remains in the existing SymbolSpec/risk engine.
    """
    s = ''.join(ch for ch in str(symbol).upper() if ch.isalpha())
    if len(s) < 6:
        return {}
    base, quote = s[:3], s[3:6]
    v = float(volume)
    if side == "SELL":
        v = -v
    return {base: v, quote: -v}


def exposure_by_currency(positions: Iterable, setup_symbol: str, setup_side: str, setup_volume: float) -> dict[str, float]:
    out: dict[str, float] = {}
    for p in positions:
        for k, v in _currency_exposure(getattr(p, "symbol", ""), getattr(p, "side", ""), getattr(p, "volume", 0.0)).items():
            out[k] = out.get(k, 0.0) + v
    for k, v in _currency_exposure(setup_symbol, setup_side, setup_volume).items():
        out[k] = out.get(k, 0.0) + v
    return out


def additional_blocks(setup, positions, policy: RiskPolicy, daily_approvals: int, atr: float | None = None) -> list[str]:
    reasons: list[str] = []
    if daily_approvals >= policy.max_daily_approvals:
        reasons.append(f"Daily approval limit reached ({policy.max_daily_approvals})")
    total_volume = sum(float(getattr(p, "volume", 0.0)) for p in positions)
    if total_volume + float(getattr(setup, "position_size", 0.0)) > policy.max_total_position_volume:
        reasons.append(f"Total position volume would exceed {policy.max_total_position_volume:g} lots")
    same_symbol = sum(1 for p in positions if getattr(p, "symbol", "") == getattr(setup, "symbol", ""))
    if same_symbol >= policy.max_symbol_positions:
        reasons.append(f"Maximum open positions for {setup.symbol} reached ({policy.max_symbol_positions})")
    if atr and atr > 0 and getattr(setup, "stop_distance", 0.0) > policy.max_stop_atr_multiple * atr:
        reasons.append(f"Stop distance exceeds {policy.max_stop_atr_multiple:g} ATR")
    exposure = exposure_by_currency(positions, setup.symbol, "BUY" if setup.signal.value == "BUY" else "SELL", setup.position_size)
    for cur, value in exposure.items():
        if abs(value) > policy.max_currency_exposure_units:
            reasons.append(f"Currency exposure limit exceeded for {cur}")
    return reasons

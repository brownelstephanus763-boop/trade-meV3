"""Request-time health snapshot. No background monitoring loop."""
from datetime import datetime, timezone


def health_snapshot(service):
    freshness = service.freshness()
    connection = dict(service.connection)
    return {
        "status": "OK" if connection.get("state") == "CONNECTED" and not service.is_stale() else "DEGRADED",
        "checked_at": datetime.now(timezone.utc).isoformat(),
        "connection": connection,
        "market_data": freshness,
        "last_scan_at": service.last_scan_at.isoformat() if service.last_scan_at else None,
        "symbols": len(service.symbols),
        "pending_setups": len(service.queue.pending()),
        "push_subscriptions": len(service.push_subscriptions),
        "kill_switch": service.kill_switch,
        "execution_enabled": False,
    }

"""Data models for the Trade Me Manual Trading Assistant.

Nothing in this module can place, close or modify a trade.
A BUY/SELL signal means "potential setup detected for your review".
"""
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional


class Direction(str, Enum):
    BULLISH = "BULLISH"
    BEARISH = "BEARISH"
    NEUTRAL = "NEUTRAL"


class Phase(str, Enum):
    CONTRACTION = "CONTRACTION"
    EXPANSION = "EXPANSION"
    TREND = "TREND"
    UNKNOWN = "UNKNOWN"


class Signal(str, Enum):
    """BUY/SELL = a potential setup was detected for user review. Never an order."""
    BUY = "BUY"
    SELL = "SELL"
    WAIT = "WAIT"
    BLOCKED = "BLOCKED"


class PriceLocation(str, Enum):
    BELOW_FAIR_VALUE = "BELOW_FAIR_VALUE"
    ABOVE_FAIR_VALUE = "ABOVE_FAIR_VALUE"
    AT_FAIR_VALUE = "AT_FAIR_VALUE"
    UNKNOWN = "UNKNOWN"


class SetupStatus(str, Enum):
    WAITING = "WAITING"      # proposed, waiting for the user's decision
    APPROVED = "APPROVED"    # user explicitly approved
    REJECTED = "REJECTED"    # user explicitly rejected (terminal)
    EXPIRED = "EXPIRED"      # user/UI explicitly marked stale (terminal, never a timer)
    BLOCKED = "BLOCKED"      # risk checks failed: should not be traded (terminal)


@dataclass(frozen=True)
class Candle:
    timestamp: object
    open: float
    high: float
    low: float
    close: float
    volume: float = 0.0
    spread: float = 0.0


@dataclass
class EngineConfig:
    # --- volatility / structure ---
    atr_short: int = 10
    atr_long: int = 40
    box_length: int = 20
    swing_left: int = 2
    swing_right: int = 2
    contraction_ratio_max: float = 0.75
    box_atr_max: float = 2.0
    expansion_buffer_atr: float = 0.05
    displacement_atr_multiple: float = 1.25
    # --- patterns ---
    double_tolerance_atr: float = 0.30
    double_lookback: int = 60            # candles searched for the two swing points
    double_min_separation: int = 3       # min candles between the two swing points
    double_min_depth_atr: float = 0.50   # min pullback between the two swing points
    rejection_wick_ratio: float = 0.50
    swing_break_buffer_atr: float = 0.05
    swing_break_lookback: int = 20       # only swings this recent can be "broken"
    min_confirmations: int = 1
    # --- stop / target ---
    stop_swing_lookback: int = 20        # how recent a swing must be to anchor the stop
    stop_atr_buffer: float = 0.20
    reward_risk: float = 2.0
    # --- risk / safety limits ---
    risk_percent: float = 0.50
    max_spread_points: float = 30.0
    max_daily_loss_percent: float = 3.0
    max_open_positions: int = 3
    # --- portfolio safety ---
    max_daily_approvals: int = 5
    max_total_position_volume: float = 3.0
    max_symbol_positions: int = 1
    max_stop_atr_multiple: float = 5.0
    max_currency_exposure_units: float = 3.0


@dataclass
class Analysis:
    direction: Direction = Direction.NEUTRAL
    phase: Phase = Phase.UNKNOWN
    fair_value: Optional[float] = None
    value_low: Optional[float] = None
    value_high: Optional[float] = None
    atr: Optional[float] = None
    close: Optional[float] = None
    contraction: bool = False
    expansion: bool = False
    displacement: bool = False
    displacement_atr: float = 0.0        # signed 3-candle move measured in ATR
    price_below_value: bool = False
    price_above_value: bool = False
    price_location: PriceLocation = PriceLocation.UNKNOWN
    patterns: list[str] = field(default_factory=list)
    confirmations: list[str] = field(default_factory=list)
    last_swing_high: Optional[float] = None   # latest confirmed swing high (prior candles)
    last_swing_low: Optional[float] = None    # latest confirmed swing low (prior candles)
    candle_high: Optional[float] = None       # high of the last completed candle
    candle_low: Optional[float] = None        # low of the last completed candle
    signal: Signal = Signal.WAIT              # BUY/SELL = potential setup for review
    reason: str = ""


@dataclass(frozen=True)
class SymbolSpec:
    """Per-symbol trading constants used for sizing. MT5DataFeed.symbol_spec() can fill these."""
    symbol: str = ""
    value_per_price_unit: float = 100000.0  # account-currency P/L per 1.0 price move per 1 lot
    point: float = 0.00001
    min_volume: float = 0.01
    max_volume: float = 100.0
    volume_step: float = 0.01


@dataclass(frozen=True)
class AccountState:
    """Read-only snapshot of the account used by the safety checks."""
    equity: float
    balance: Optional[float] = None
    daily_loss_percent: float = 0.0
    open_positions: int = 0


@dataclass
class TradeSetup:
    """A PROPOSED trade for the user to review. It is not an order.

    It only becomes executable when its status is APPROVED, and that
    happens only through an explicit call to ApprovalQueue.approve().
    """
    setup_id: str
    symbol: str
    timestamp: Any
    direction: Direction              # BULLISH for BUY, BEARISH for SELL
    signal: Signal
    entry: float
    stop_loss: Optional[float]
    take_profit: Optional[float]
    stop_distance: float
    risk_percent: float
    risk_amount: float
    position_size: float
    reward_risk: float
    market_direction: Direction
    market_phase: Phase
    fair_value: Optional[float]
    value_low: Optional[float]
    value_high: Optional[float]
    price_location: PriceLocation
    patterns: list[str]
    confirmations: list[str]
    reason: str
    status: SetupStatus = SetupStatus.WAITING
    # --- safety-check results ---
    spread_points: float = 0.0
    spread_status: str = "OK"
    daily_loss_status: str = "OK"
    open_positions_status: str = "OK"
    blocked_reasons: list[str] = field(default_factory=list)
    # --- transparency: how every number was produced ---
    calculation: list[str] = field(default_factory=list)
    # --- user decision record ---
    decided_at: Any = None
    decision_note: str = ""

    @property
    def is_executable(self) -> bool:
        """True only for a setup the user explicitly approved and that passed risk checks."""
        return self.status == SetupStatus.APPROVED and not self.blocked_reasons

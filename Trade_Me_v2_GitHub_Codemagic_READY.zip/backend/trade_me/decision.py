"""Human-readable decision stages derived from existing setup evidence."""
from .models import SetupStatus, Signal


def stage(setup) -> str:
    if setup.status == SetupStatus.BLOCKED:
        return "BLOCKED"
    if setup.status in (SetupStatus.APPROVED, SetupStatus.REJECTED, SetupStatus.EXPIRED):
        return setup.status.value
    if setup.signal not in (Signal.BUY, Signal.SELL):
        return "WAITING"
    confirmations = len(setup.confirmations) + len(setup.patterns)
    if confirmations >= 2 and setup.stop_loss is not None and setup.take_profit is not None:
        return "CONFIRMED"
    if confirmations >= 1:
        return "FORMING"
    return "WATCHING"

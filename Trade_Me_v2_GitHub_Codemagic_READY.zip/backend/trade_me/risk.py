"""Risk maths and safety checks. Pure functions: they calculate, they never trade."""
import math
from dataclasses import dataclass, field


@dataclass
class RiskDecision:
    """Legacy first-failure result kept for compatibility. Prefer RiskAssessment."""
    allowed: bool
    reason: str
    risk_amount: float = 0.0
    volume: float = 0.0


@dataclass
class RiskAssessment:
    allowed: bool
    risk_percent: float
    risk_amount: float
    stop_distance: float
    position_size: float
    spread_points: float
    spread_ok: bool
    daily_loss_ok: bool
    open_positions_ok: bool
    size_ok: bool
    blocked_reasons: list[str] = field(default_factory=list)


def position_size(equity, risk_percent, stop_distance, value_per_price_unit,
                  min_volume=0.01, max_volume=100.0, volume_step=0.01):
    """Lots such that a stop-out loses at most equity*risk_percent%.

    Rounded DOWN to the volume step. Returns 0.0 when even the minimum volume would
    risk more than the budget (the setup is then blocked rather than over-risked).
    """
    if equity <= 0 or stop_distance <= 0 or value_per_price_unit <= 0 or volume_step <= 0:
        return 0.0
    budget = equity * risk_percent / 100
    raw = budget / (stop_distance * value_per_price_unit)
    volume = math.floor(round(raw / volume_step, 9)) * volume_step
    if volume < min_volume:
        return 0.0
    return round(min(max_volume, volume), 8)


def reward_risk_ratio(entry, stop_loss, take_profit):
    risk = abs(entry - stop_loss)
    if risk <= 0:
        return 0.0
    return abs(take_profit - entry) / risk


def assess_risk(equity, risk_percent, stop_distance, value_per_price_unit,
                spread_points, max_spread_points, daily_loss_percent, max_daily_loss_percent,
                open_positions, max_open_positions,
                min_volume=0.01, max_volume=100.0, volume_step=0.01) -> RiskAssessment:
    """Evaluate every safety limit (no short-circuit, so all failures are visible)."""
    reasons = []
    spread_ok = spread_points <= max_spread_points
    if not spread_ok:
        reasons.append(f"Spread too high ({spread_points:g} > {max_spread_points:g} points)")
    daily_ok = daily_loss_percent < max_daily_loss_percent
    if not daily_ok:
        reasons.append(f"Daily loss limit reached ({daily_loss_percent:g}% >= {max_daily_loss_percent:g}%)")
    positions_ok = open_positions < max_open_positions
    if not positions_ok:
        reasons.append(f"Maximum open positions reached ({open_positions} >= {max_open_positions})")
    volume = position_size(equity, risk_percent, stop_distance, value_per_price_unit,
                           min_volume, max_volume, volume_step)
    size_ok = volume > 0
    if not size_ok:
        reasons.append("Invalid position size (stop too wide for the risk budget, or bad inputs)")
    return RiskAssessment(
        allowed=not reasons, risk_percent=risk_percent,
        risk_amount=equity * risk_percent / 100 if equity > 0 else 0.0,
        stop_distance=stop_distance, position_size=volume, spread_points=spread_points,
        spread_ok=spread_ok, daily_loss_ok=daily_ok, open_positions_ok=positions_ok,
        size_ok=size_ok, blocked_reasons=reasons)


def risk_check(equity, risk_percent, stop_distance, value_per_price_unit, spread_points,
               max_spread_points, daily_loss_percent, max_daily_loss_percent,
               open_positions, max_open_positions) -> RiskDecision:
    a = assess_risk(equity, risk_percent, stop_distance, value_per_price_unit, spread_points,
                    max_spread_points, daily_loss_percent, max_daily_loss_percent,
                    open_positions, max_open_positions)
    if not a.allowed:
        return RiskDecision(False, a.blocked_reasons[0])
    return RiskDecision(True, "Risk checks passed", a.risk_amount, a.position_size)

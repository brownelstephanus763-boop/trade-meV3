"""Start Trade Me on the PC that runs MetaTrader 5 (Windows). The phone opens the printed URL.
Read-only MT5 feed. No execution module is imported. Usage:
    python run_app.py --symbols EURUSD GBPUSD XAUUSD USDJPY --timeframe M15
Reachable from a phone (any host other than localhost) REQUIRES an access token, set via the
TRADE_ME_TOKEN environment variable (preferred) or --token. The token is never printed:
    set TRADE_ME_TOKEN=choose-a-long-random-value
    python run_app.py --host 0.0.0.0"""
import argparse
import os
import sys

from trade_me.mt5_feed import MT5DataFeed
from trade_me_app.server import LOOPBACK_HOSTS, create_app
from trade_me_app.service import TradeMeService

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--symbols", nargs="+", default=["EURUSD", "GBPUSD", "XAUUSD", "USDJPY"])
    ap.add_argument("--timeframe", default="M15")
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8765)
    ap.add_argument("--token", default=None, help="access token (prefer the TRADE_ME_TOKEN environment variable)")
    a = ap.parse_args()
    token = a.token or os.environ.get("TRADE_ME_TOKEN") or None
    if a.host not in LOOPBACK_HOSTS and not token:
        sys.exit("Refusing to start: --host %s exposes the bridge beyond this PC. Set TRADE_ME_TOKEN first." % a.host)
    svc = TradeMeService(MT5DataFeed(), a.symbols, a.timeframe)
    svc.connect()
    print("MT5:", svc.connection["message"])
    print("Access token:", "required" if token else "not required (localhost only)")
    create_app(svc, token=token, host=a.host).run(host=a.host, port=a.port, threaded=False)

# Trade Me v2 — Android + Server

This is the consolidated Trade Me v2 package for GitHub + Codemagic.

## Codemagic

`codemagic.yaml` is already included at the repository root. Connect this repository to Codemagic and run `trademe_android_debug`. The resulting APK is published as a build artifact.

## Layout

- `app/` — Android APK client
- `backend/` — existing Trade Me server/analysis engine
- `build.gradle`, `settings.gradle`, `gradle.properties` — Android build configuration
- `codemagic.yaml` — single Codemagic workflow

Tests, pytest caches, generated build folders, and duplicate project copies are intentionally excluded from this release package.

The Android client remains a thin client and does not contain a second trading engine.
